package com.example.demo.entity;
import java.io.Serializable;
public class Team implements Serializable{
	private static final long serialVersionUID = 1L;	
	private long tid;
	private String teamName;
	private int tokenNo;
	
	public long getTid() {
		return tid;
	}
	public void setTid(long tid) {
		this.tid = tid;
	}
	public String getTeamName() {
		return teamName;
	}
	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}
	public int getTokenNo() {
		return tokenNo;
	}
	public void setTokenNo(int tokenNo) {
		this.tokenNo = tokenNo;
	}
}
